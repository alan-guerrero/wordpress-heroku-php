<div id="sln-setting-error" class="updated error">
    <p><?php _e('Your free version is expired. <a href="http://salonbookingsystem.com/salon-booking-plugin-pricing/" target="blank">Please upgrade Salon Booking to a PRO version</a>.','salon-booking-system') ?>

    <p><?php _e('<strong>Do you want a 20% discount ? <a href="http://salonbookingsystem.com/invite-friends-get-20-discount-first-purchase/" target="blank">INVITE YOUR FRIENDS!</a></strong></p>','salon-booking-system');?></p>
</div>


