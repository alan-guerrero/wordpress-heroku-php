<div id="sln-setting-error" class="updated error">
    <h3><?php _e('Salon booking plugin needs a valid license','sln') ?></h3>

    <p><a href="<?php echo $licenseUrl ?>"><?php _e('<p>Please insert your license key','sln');?></a></p>
</div>
