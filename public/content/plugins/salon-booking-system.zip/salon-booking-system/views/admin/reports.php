<div class="wrap sln-bootstrap">
	<h1><?php _e( 'Reports', 'salon-booking-system' ) ?></h1>
	<?php include '_reports_bookings.php' ?>
</div>
