<tr>
    <td align="left" valign="top" style="border:1px solid #9a9a9a;">
	<table width="100%" cellspacing="0" cellpadding="0" border="0">
	    <tr>
		<td align="center" valign="top" height="14" style="font-size:1px;line-height:1px;">&nbsp;</td>
	    </tr>
	    <tr>
		<td align="center" valign="top">
		    <table width="552" cellspacing="0" cellpadding="0" border="0" class="wrap1002">
			<tr>
			    <td align="center" valign="top" style="font-size:16px;line-height:20px;color:#006dbc;font-weight:500; font-family: 'Avenir-Roman',sans-serif,arial;" width="144"  class="font2">
				<a href="<?php echo SLN_Helper_CalendarLink::getGoogleLink($booking) ?>" target="_blank" style="text-decoration:underline;color:#006dbc;">
				    <?php _e("Add to", 'salon-booking-system') ?>
				    <br class="br1">
				    <?php _e("Google Calendar", 'salon-booking-system') ?>
				</a>
			    </td>
			    <td align="center" valign="top" style="font-size:16px;line-height:20px;color:#006dbc;font-weight:500;font-family: 'Avenir-Roman',sans-serif,arial;" width="245" class="font2">
				<a href="<?php echo SLN_Helper_CalendarLink::getICallLink($booking, $data) ?>" target="_blank" style="text-decoration:underline;color:#006dbc;">
				    <?php _e("Add to", 'salon-booking-system') ?>
				    <br class="br1">
				    <?php _e("iCal calendar", 'salon-booking-system') ?>
				</a>
			    </td>
			    <td align="center" valign="top" style="font-size:16px;line-height:20px;color:#006dbc;font-weight:500;font-family: 'Avenir-Roman',sans-serif,arial;" width="163"  class="font2">
				<a href="<?php echo SLN_Helper_CalendarLink::getOutlookLink($booking) ?>" target="_blank" style="text-decoration:underline;color:#006dbc;">
				    <?php _e("Add to", 'salon-booking-system') ?>
				    <br class="br1">
				    <?php _e("Outlook Calendar", 'salon-booking-system') ?>
				</a>
			    </td>
			</tr>
		    </table>
		</td>
	    </tr>
	    <tr>
		<td align="center" valign="top" height="14" style="font-size:1px;line-height:1px;">&nbsp;</td>
	    </tr>
	</table>
    </td>
</tr>
<!--4th blk ends here-->
<tr>
    <td align="center" valign="top" height="25" style="font-size:1px;line-height:1px;">&nbsp;</td>
</tr>