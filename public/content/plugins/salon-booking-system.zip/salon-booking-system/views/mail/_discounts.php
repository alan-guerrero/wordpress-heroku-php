<!--5th blk starts here-->
<tr>
    <td align="center" valign="top">
	<table width="521" cellspacing="0" cellpadding="0" border="0" class="wrap1002">
	    <tr>
		<td align="left" valign="top" style="font-size:16px;line-height:20px;color:#4d4d4d;font-weight:bold;font-family: 'Avenir-Medium',sans-serif,arial;">
		    Discounts available for you:
		</td>
	    </tr>
	    <tr>
		<td align="center" valign="top" height="23" style="font-size:1px;line-height:1px;" class="height3">&nbsp;</td>
	    </tr>
	    <tr>
		<td align="left" valign="top" style="font-size:18px;line-height:20px;color:#4d4d4d;font-weight:500;font-family: 'Avenir-Medium',sans-serif,arial;">
		    30% discount on Hair-cut<br  class="br1">
		    <span style="font-size:16px;letter-spacing:0.1px;" class="font3">from  April 12th 2019 to April 20th 2019</span>
		</td>
	    </tr>
	    <tr>
		<td align="center" valign="top" height="18" style="font-size:1px;line-height:1px;">&nbsp;</td>
	    </tr>
	    <tr>
		<td align="left" valign="top" style="font-size:18px;line-height:20px;color:#4d4d4d;font-weight:500;font-family: 'Avenir-Medium',sans-serif,arial;">
		    15% discount on Hair color<br  class="br1">
		    <span style="font-size:16px;letter-spacing: 0.1px;" class="font3">from  April 12th 2019 to April 20th 2019,<br class="br1">
			using this coupon code: </span><span style="font-family: 'Avenir-Medium',sans-serif,arial;font-weight:bold;font-size:16px;">DISCOUNTNOW!</span>
		</td>
	    </tr>
	    <tr>
		<td align="center" valign="top" height="28" style="font-size:1px;line-height:1px;" class="height3">&nbsp;</td>
	    </tr>
	</table>
    </td>
</tr>
<!--5th blk ends here-->