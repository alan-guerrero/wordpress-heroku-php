<style type="text/css">
    #post-preview, #view-post-btn,
    #misc-publishing-actions #visibility,
    #major-publishing-actions,
    #post-body-content {
        display: none;
    }
</style>
<script type="text/javascript">
    jQuery(function () {
        jQuery('#_sln_booking_status, #post_status').change(function () {
            jQuery('#_sln_booking_status, #post_status').val(jQuery(this).val());
        });
    });
</script>