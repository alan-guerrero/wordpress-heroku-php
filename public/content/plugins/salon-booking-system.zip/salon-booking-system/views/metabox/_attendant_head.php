<style type="text/css">
    #post-preview, #view-post-btn,
    #edit-slug-box {
        display: none;
    }
</style>