convert img/admin_icon_full.png  -resize 20x20\! img/admin_icon.png
convert img/settings_icon_full.png  -resize 20x20\! img/settings_icon.png
